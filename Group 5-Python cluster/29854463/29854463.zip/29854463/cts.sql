from datetime import datetime

class Course:
    def _init_(self, course_id, title, description, instructor_id, capacity):
        self.course_id = course_id
        self.title = title
        self.description = description
        self.instructor_id = instructor_id
        self.capacity = capacity

    def update_course(self, title=None, description=None, instructor_id=None, capacity=None):
        if title:
            self.title = title
        if description:
            self.description = description
        if instructor_id:
            self.instructor_id = instructor_id
        if capacity:
            self.capacity = capacity

class Student:
    def _init_(self, student_id, name, email, address):
        self.student_id = student_id
        self.name = name
        self.email = email
        self.address = address

    def update_student(self, name=None, email=None, address=None):
        if name:
            self.name = name
        if email:
            self.email = email
        if address:
            self.address = address

class Instructor:
    def _init_(self, instructor_id, name, email, expertise):
        self.instructor_id = instructor_id
        self.name = name
        self.email = email
        self.expertise = expertise

    def update_instructor(self, name=None, email=None, expertise=None):
        if name:
            self.name = name
        if email:
            self.email = email
        if expertise:
            self.expertise = expertise

class Enrollment:
    def _init_(self, enrollment_id, student_id, course_id, enrollment_date):
        self.enrollment_id = enrollment_id
        self.student_id = student_id
        self.course_id = course_id
        self.enrollment_date = enrollment_date

    def update_enrollment(self, student_id=None, course_id=None, enrollment_date=None):
        if student_id:
            self.student_id = student_id
        if course_id:
            self.course_id = course_id
        if enrollment_date:
            self.enrollment_date = enrollment_date

class OnlineLearningPlatform:
    def _init_(self):
        self.courses = {}
        self.students = {}
        self.instructors = {}
        self.enrollments = {}

    def add_course(self, course_id, title, description, instructor_id, capacity):
        if course_id in self.courses:
            raise Exception("Course ID already exists.")
        self.courses[course_id] = Course(course_id, title, description, instructor_id, capacity)

    def update_course(self, course_id, title=None, description=None, instructor_id=None, capacity=None):
        if course_id not in self.courses:
            raise Exception("Course ID not found.")
        self.courses[course_id].update_course(title, description, instructor_id, capacity)

    def delete_course(self, course_id):
        if course_id not in self.courses:
            raise Exception("Course ID not found.")
        del self.courses[course_id]

    def add_student(self, student_id, name, email, address):
        if student_id in self.students:
            raise Exception("Student ID already exists.")
        self.students[student_id] = Student(student_id, name, email, address)

    def update_student(self, student_id, name=None, email=None, address=None):
        if student_id not in self.students:
            raise Exception("Student ID not found.")
        self.students[student_id].update_student(name, email, address)

    def delete_student(self, student_id):
        if student_id not in self.students:
            raise Exception("Student ID not found.")
        del self.students[student_id]

    def add_instructor(self, instructor_id, name, email, expertise):
        if instructor_id in self.instructors:
            raise Exception("Instructor ID already exists.")
        self.instructors[instructor_id] = Instructor(instructor_id, name, email, expertise)

    def update_instructor(self, instructor_id, name=None, email=None, expertise=None):
        if instructor_id not in self.instructors:
            raise Exception("Instructor ID not found.")
        self.instructors[instructor_id].update_instructor(name, email, expertise)

    def delete_instructor(self, instructor_id):
        if instructor_id not in self.instructors:
            raise Exception("Instructor ID not found.")
        del self.instructors[instructor_id]

    def enroll_student(self, enrollment_id, student_id, course_id):
        if enrollment_id in self.enrollments:
            raise Exception("Enrollment ID already exists.")
        if student_id not in self.students:
            raise Exception("Student ID not found.")
        if course_id not in self.courses:
            raise Exception("Course ID not found.")
        enrollment_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.enrollments[enrollment_id] = Enrollment(enrollment_id, student_id, course_id, enrollment_date)

    def update_enrollment(self, enrollment_id, student_id=None, course_id=None, enrollment_date=None):
        if enrollment_id not in self.enrollments:
            raise Exception("Enrollment ID not found.")
        self.enrollments[enrollment_id].update_enrollment(student_id, course_id, enrollment_date)

    def cancel_enrollment(self, enrollment_id):
        if enrollment_id not in self.enrollments:
            raise Exception("Enrollment ID not found.")
        del self.enrollments[enrollment_id]

def main():
    platform = OnlineLearningPlatform()

    try:
        platform.add_course("C001", "Python Programming", "Learn Python from scratch", "I001", 30)
        platform.add_course("C002", "Data Structures", "Learn about data structures", "I002", 25)
        platform.add_student("S001", "John Doe", "john@example.com", "123 Main St")
        platform.add_student("S002", "Jane Smith", "jane@example.com", "456 Maple Ave")
        platform.add_instructor("I001", "Dr. Brown", "brown@example.com", "Computer Science")
        platform.add_instructor("I002", "Dr. Green", "green@example.com", "Mathematics")
        platform.enroll_student("E001", "S001", "C001")
        platform.enroll_student("E002", "S002", "C002")
        platform.update_course("C001", title="Advanced Python Programming")

        for course_id, course in platform.courses.items():
            print(f"Course ID: {course.course_id}, Title: {course.title}, Description: {course.description}, Instructor ID: {course.instructor_id}, Capacity: {course.capacity}")

    except Exception as e:
        print(f"Error: {e}")

if _name_ == "_main_":
    main()